/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Account.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkasandr <lkasandr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/24 10:02:41 by lkasandr          #+#    #+#             */
/*   Updated: 2021/08/25 16:26:05 by lkasandr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Account.hpp"
#include <iostream>
#include <ctime>
#include <iomanip>

//переменные приватные:
// static int	_nbAccounts; +
// static int	_totalAmount; +
// static int	_totalNbDeposits;
// static int	_totalNbWithdrawals;

// int				_accountIndex; +
// int				_amount; +
// int				_nbDeposits;
// int				_nbWithdrawals;

int Account::_nbAccounts;
int Account::_totalAmount;
int Account::_totalNbDeposits;
int Account::_totalNbWithdrawals;

//Конструктор
Account::Account(int initial_deposit)
{
	_accountIndex = _nbAccounts;
	_nbAccounts++;
	_amount = initial_deposit;
	_totalAmount += _amount;
	_totalNbDeposits = 0;
	_totalNbWithdrawals = 0;
	_nbDeposits = 0;
	_nbWithdrawals = 0;
	
	_displayTimestamp();
	std::cout << "index:" << _accountIndex 
	<< ";amount:" << _amount 
	<< ";created" << std::endl;
}

// Account::Account(void)
// {
	
// }

//Деструктор
Account::~Account(void)
{
	_displayTimestamp();
	std::cout << "index:" << _accountIndex 
	<< ";amount:" << _amount 
	<< ";closed" << std::endl;
}


// //Методы паблик
// int Account::getNbAccounts(void)
// {
	
// }

// int Account::getTotalAmount(void)
// {

// }

// int Account::getNbDeposits(void)
// {

// }

// int Account::getNbDeposits(void)
// {

// }

void Account::displayAccountsInfos(void)
{
	_displayTimestamp();
	std::cout << "accounts:" << _nbAccounts 
	<< ";total:" << _totalAmount 
	<< ";deposits:" << _totalNbDeposits
	<< ";withdrawals:" << _totalNbWithdrawals 
	<< std::endl;
}

void Account::makeDeposit(int deposit)
{
	_totalNbDeposits++;
	_totalAmount += deposit;
	_nbDeposits += 1;
	_displayTimestamp();
	
	std::cout << "index:" << _accountIndex 
	<< ";p_amount:" << _amount
	<< ";deposit:" << deposit
	<< ";amount:" << _amount + deposit
	<< ";nb_deposits:" << _nbDeposits
	<< std::endl;

	_amount += deposit;
}

bool Account::makeWithdrawal(int withdrawal)
{	
	_displayTimestamp();
	std::cout << "index:" << _accountIndex << ";p_amount:" << _amount << ";withdrawal:"; 
	if (withdrawal > _amount)
		std::cout << "refused";
	else
	{
		_nbWithdrawals += 1;
		std::cout << withdrawal 
		<< ";amount:" << _amount - withdrawal
		<< ";nb_withdrawals:" << _nbWithdrawals;
		_amount -= withdrawal;
		_totalAmount -= withdrawal;
		_totalNbWithdrawals++;
	}
	std::cout << std::endl;
	return (0);
}

// int Account::checkAmount(void) const
// {

// }

void Account::displayStatus(void) const
{
	_displayTimestamp();
	std::cout << "index:" << _accountIndex 
	<< ";amount:" << _amount
	<< ";deposits:" << _nbDeposits
	<< ";withdrawals:" << _nbWithdrawals
	<< std::endl;
}

//Методы приват
void	Account::_displayTimestamp(void)
{
	time_t now = time(0);

	tm *ltm = localtime(&now);
	std::cout << "[" << std::setfill('0')  << 1900 + ltm->tm_year 
	<< std::setw(2) << 1 + ltm->tm_mon << std::setw(2)
	<< ltm->tm_mday << "_" << std::setw(2)
	<< ltm->tm_hour << std::setw(2) 
	<< ltm->tm_min << std::setw(2)
	<< ltm->tm_sec << "] ";
}